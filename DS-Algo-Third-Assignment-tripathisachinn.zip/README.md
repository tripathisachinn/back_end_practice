# ds-algo-third-assignment
# DS Algo Third Assignment

Topics Covered are Trie, Sorting

#### Reference Links

1. Trie -> https://www.youtube.com/watch?v=AXjmTQ8LEoI + https://www.youtube.com/watch?v=pxEvz1K2Z70 / https://www.youtube.com/watch?v=YG6iX28hmd0
2. Bubble sort -> https://www.youtube.com/watch?v=Vca808JTbI8
3. Merge sort -> https://www.youtube.com/watch?v=nCNfu_zNhyI
4. Insertion sort -> https://www.youtube.com/watch?v=K0zTIF3rm9s
5. Shell sort -> https://www.youtube.com/watch?v=VxNr9Vudp4Y
6. Selection Sort -> https://www.youtube.com/watch?v=5KjapFQNxUo

## Assignment Questions

### Trie

1. Implement Trie
2. https://leetcode.com/problems/longest-word-in-dictionary/


### Sorting

Implement Following sorting algorithms<br/>

4. Bubble Sort<br/>
5. Merge Sort<br/>
6. Insertion Sort<br/>
7. Shell Sort<br/>
8. Selection Sort<br/>

