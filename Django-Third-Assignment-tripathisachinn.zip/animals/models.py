from django.db import models


# Create your models here.
class Mammal(models.Model):
  name=models.CharField(max_length=40)
  species=models.CharField(max_length=20)
  food=models.CharField(max_length=20)
  last_feed_time=models.DateTimeField(auto_now_add=True)
  GENDER_CHOICES = (
      ('M', 'Male'),
      ('F', 'Female'),
  )
  gender = models.CharField(max_length=1, choices=GENDER_CHOICES)

  def __str__(self):
    return self.name

class Bird(models.Model):
  name=models.CharField(max_length=40)
  species=models.CharField(max_length=20)
  food=models.CharField(max_length=20)
  last_feed_time=models.DateTimeField(auto_now_add=True)

  def __str__(self):
    return self.name

class Fish(models.Model):
  color=models.CharField(max_length=40)
  species=models.CharField(max_length=40)
  food=models.CharField(max_length=40)
  count=models.IntegerField()
  last_feed_time=models.DateTimeField(auto_now_add=True)

  def __str__(self):
    return self.species
  