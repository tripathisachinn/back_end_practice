from django.urls import path
from . import views

urlpatterns = [
  # path('index/',views.index,name="index"),
  path('mammals/',views.getorpostmammal,name="mammals"),
  path('mammals/<str:mammals>',views.getorpostmammal,name="mammals"),
  path('birds/',views.getorpostbird,name="birds"),
  path('birds/<str:birds>',views.getorpostbird,name="birds"),
  path('fishes/',views.getorpostfish,name="fishes"),
  path('fishes/<str:fishes>',views.getorpostfish,name="fishes")
]