from django.shortcuts import render
from django.http import HttpResponse,JsonResponse
from django.views.decorators.csrf import csrf_exempt
from animals import models
import datetime

@csrf_exempt
def index(request):
  return HttpResponse("Hello I am Saini")

@csrf_exempt
def getorpostmammal(request,*args,**kwargs):
  if request.method=='GET':
    if 'mammals' in kwargs:
      mammals=models.Mammal.objects.get(name=kwargs['mammals'])
      return JsonResponse({
        'name':mammals.name,
        'species':mammals.species,
        'gender':mammals.gender,
        'food':mammals.food,
        })

    else: 
      mammals = models.Mammal.objects.all()
      b=[]
      for mammal in mammals:
        a=[]
        a.append(mammal.name)
        a.append(mammal.species)
        a.append(mammal.gender)
        a.append(mammal.food)
        b.append(a)
      return JsonResponse({"data":b})
  
  elif request.method=='POST':
    mammals=request.POST
    models.Mammal.objects.create(
      name=mammals['name'],
      species=mammals['species'],
      food=mammals['food'],
      gender=mammals['gender']
    )
    return JsonResponse({"created":{"name":mammals['name']}})

  elif request.method=='PUT':
    if 'mammals' in kwargs:
      mammals=models.Mammal.objects.get(name=kwargs['mammals'])
      mammals.last_feed_time=datetime.datetime.now()
      mammals.save()
      return JsonResponse(
        {
          "Feeded":str(kwargs['mammals'])
        }
      )

  elif request.method=='DELETE':
    if 'mammals' in kwargs:
      mammals=models.Mammal.objects.get(name=kwargs['mammals'])
      mammals.delete()
    return JsonResponse(
      {
        "Deleted ":str(kwargs['mammals'])
      }
    )
  
      

@csrf_exempt
def getorpostbird(request,*args,**kwargs):
  if request.method=='GET':
    if 'birds' in kwargs:
      birds=models.Bird.objects.get(name=kwargs['birds'])
      return JsonResponse({
          'name':birds.name,
          'species':birds.species,
          'food':birds.food
        })

    else:  
      birds = models.Bird.objects.all()
      b=[]
      for bird in birds:
        a=[]
        a.append(bird.name)
        a.append(bird.species)
        a.append(bird.food)
        b.append(a)
      return JsonResponse({"data":b})

  elif request.method=='POST':
    birds=request.POST
    models.Bird.objects.create(
      name=birds['name'],
      species=birds['species'],
      food=birds['food'],
    )
    return JsonResponse({"created":{"name":birds['name']}})

  elif request.method=='PUT':
    if 'birds' in kwargs:
      birds=models.Bird.objects.get(name=kwargs['birds'])
      birds.last_feed_time=datetime.datetime.now()
      birds.save()

      return JsonResponse(
        {
          "Feeded":str(kwargs['birds'])
        }
      )

  elif request.method=='DELETE':
    if 'birds' in kwargs:
      birds=models.Bird.objects.get(name=kwargs['birds'])
      birds.delete()
      return JsonResponse(
        {
          "Deleted ":str(kwargs['birds'])
        }
      )
  

            
@csrf_exempt
def getorpostfish(request,*args,**kwargs):
  if request.method=='GET':
    if 'fishes' in kwargs:
      fishes=models.Fish.objects.get(species=kwargs['fishes'])
      return JsonResponse({
          'color':fishes.color,
          'species':fishes.species,
          'food':fishes.food,
          'count':fishes.count
        })
      
    else:
      fishes = models.Fish.objects.all()
      b=[]
      for fish in fishes:
        a=[]
        a.append(fish.color)
        a.append(fish.species)
        a.append(fish.food)
        a.append(fish.count)
        b.append(a)
      return JsonResponse({"data":b})

  elif request.method=='POST':
    fishes=request.POST
    models.Fish.objects.create(
      color=fishes['color'],
      species=fishes['species'],
      food=fishes['food'],
      count=fishes['count']
    )
    return JsonResponse({"created":{"species":fishes['species']}})

  elif request.method=='PUT':
    if 'fishes' in kwargs:
      fishes=models.Fish.objects.get(species=kwargs['fishes'])
      fishes.last_feed_time=datetime.datetime.now()
      fishes.save()

      return JsonResponse(
        {
          "Feeded":str(kwargs['fishes'])
        }
      )

  elif request.method=='DELETE':
    if 'fishes' in kwargs:
      fishes=models.Fish.objects.get(species=kwargs['fishes'])
      fishes.delete()
      return JsonResponse(
        {
          "Deleted ":str(kwargs['fishes'])
        }
      )
  
