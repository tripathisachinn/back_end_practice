# python_fifth_assignment


## Question 1

Write an “abstract” class, Box, and use it to define some methods which any box object should have: add, for adding any number of items to the box, empty, for taking all the items out of the box and returning them as a list, and count, for counting the items which are currently in the box. Write a simple Item class which has a name attribute and a value attribute – you can assume that all the items you will use will be Item objects. Now write two subclasses of Box which use different underlying collections to store items: ListBox should use a list, and DictBox should use a dict.

## Question 2

Create a class called Numbers, which has a single class attribute called MULTIPLIER, and a constructor which
takes the parameters x and y (these should all be numbers). </br>
(a) Write a method called add which returns the sum of the attributes x and y.</br>
(b) Write a class method called multiply, which takes a single number parameter a and returns the product
of a and MULTIPLIER.</br>
(c) Write a static method called subtract, which takes two number parameters, b and c, and returns b - c.</br>
(d) Write a method called value which returns a tuple containing the values of x and y. Make this method
into a property, and write a setter and a deleter for manipulating the values of x and y</br>

## Question 3

Construct a class named “Book” that assigns title, author and format as initial values.</br>
Create a class named “Library” that extends “Book” and assigns available as initial value, a method named updateAvailability that updates availability of the book, and a method named “__str__” that returns the string representation of the class.</br>

