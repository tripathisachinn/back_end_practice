c1 = lion = 2
c2 = white_tiger = 2
h1 = red_deer = 50
h2 = elephant = 10
h3 = spider_monkey = 100
h4 = zebra = 17
h5 = rhinoceroses= 10
c3 = black_panther= 10
c4 = harpy_eagles= 12
c5 = white_backed_vulture = 5
# Herbivorous are 3,4,5,6,7
# Carnivorous are 1,2,8,9,20
herbi = h1+h2+h3+h4+h5
carni = c1+c2+c3+c4+c5
print(f"There are ",lion, " Lions")
print(f"There are ",white_tiger, " White Tigers")
print(f"There are ",red_deer, " Red Deers")
print(f"There are ",elephant, " Elephants")
print(f"There are ",spider_monkey, " Spider Monkeys")
print(f"There are ",zebra, " Zebras")
print(f"There are ",rhinoceroses, " Rhinoceroses")
print(f"There are ",black_panther, " Black Panther")
print(f"There are ",harpy_eagles, " Harpy Eagles")
print(f"There are ",white_backed_vulture, " White Backed Vultures")
print(f"There are total ",herbi, " Herbivorous animals")
print(f"There are total ",carni, " Carnivorous animals")
