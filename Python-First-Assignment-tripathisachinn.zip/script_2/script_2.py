print("January \n February \n March \n April \n May \n June \n July \n August \n September \n October \n November \n December \n")
nl = "\n"
print("Monday",nl,"Tuesday",nl,"Wednesday",nl,"Thursday",nl,"Friday",nl,"Saturday",nl,"Sunday")
for i in range(1,11):
  print(i)