days_list = ["Monday", "Tuesday", "Wednesday","Thursday","Friday","Saturday","Sunday"]
days_tuple = ("Monday", "Tuesday", "Wednesday","Thursday","Friday","Saturday","Sunday")
print(days_list)
print(days_tuple)

if 1<2:
  print(True)
else:
  print(False)
if 99>=8:
  print(True)
else:
  print(False)
if 345678+77777 < 66666-90:
  print(True)
else:
  print(False)
if 7896*5555 == 8989898:
  print(True)
else:
  print(False) 