numbers = [1, 2, 3, 4, 5]
weekdays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
num = [222, 100, 85, 500, 300]
# for printing the numbers list
for i in range(len(numbers)):
  print(numbers[i],)

i = 0
while i < len(numbers):
  print(numbers[i])
  i = i + 1          
# for printing the weekdays list
for i in range(len(weekdays)):
  print(weekdays[i],)

while i < len(weekdays):
  print(weekdays[i])
  i = i + 1
  pass

  # to for sum of num
sum = 0
for nums in num:
  sum += nums
print(f"The sum from for loop: " ,sum)


sum1 = 0
sizeOfList = len(num)
count = 0
while count < sizeOfList:
    sum1 = sum1 + num[count]
    count = count + 1
print("The sum from while loop: ", sum1)
