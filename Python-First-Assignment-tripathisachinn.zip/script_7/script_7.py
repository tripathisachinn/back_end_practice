def bmi_script_5(height, weight):
     return ""

if __name__ == '__main__':
     name = input("What is your Name?\n")
     height = float(input("Hi "+name +" What is your Height in metres?\n"))
     weight = int(input("What is your Weight in Kg?\n"))
     bmi_script_5(height, weight)

bmi = round(weight/(height*height),1)
status = ""

if bmi < 18.5:
  status = "underweight"
elif bmi >= 18.5 and bmi <= 24.9:
  status = "normal"
elif bmi >= 25 and bmi <= 29.9:
  status = "overweight"
else:
  status = "obese"

print(f"The BMI is ",bmi, "which means you are ",status, "->")


# getting an error while importing sys 
# A module you have imported isn't available at the moment. It will be available soon.