#parent class
class Animal(object):
  def __init__(self, name, ctg):
    self.name = name
    self.ctg = ctg
  
  #child class

class Lion(Animal):
  def __init__(self, name, ctg, food, noise):
    super().__init__(name, ctg)
    self.food = food
    self.noise = noise

class Tiger(Animal):
  def __init__(self, name, ctg, food, noise):
    super().__init__(name, ctg)
    self.food = food
    self.noise = noise

class Giraffe(Animal):
  def __init__(self, name, ctg, food, noise):
    super().__init__(name, ctg)
    self.food = food
    self.noise = noise

class Elephant(Animal):
  def __init__(self, name, ctg, food, noise):
    super().__init__(name, ctg)
    self.food = food
    self.noise = noise

class Deer(Animal):
  def __init__(self, name, ctg, food, noise):
    super().__init__(name, ctg)
    self.food = food
    self.noise = noise

# taking input from User

a1 = input("Enter count of Lions:")

a2 = input("Enter count of Tiger:")

a3 = input("Enter count of Giraffe:")

a4 = input("Enter count of Elephant:")

a5 = input("Enter count of Deer:")
