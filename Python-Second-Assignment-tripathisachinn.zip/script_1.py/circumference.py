import math

def find_Circumference(radius):
    return 2 * math.pi * radius

r = float(input(' Please Enter the radius of a circle: '))

circumference = find_Circumference(r)

print(" Circumference Of a Circle = %.2f" %circumference)

# Completed and working.
