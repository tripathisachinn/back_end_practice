# add code to read data from sample.txt file
# and print here
f=open("sample.txt", "r")
read_lines = f.read()
print(read_lines)

f.close()

#completed and working
