def file_process(file_name):
     print("Here are the contents of",file_name+".txt" )
     # Add code to read numbers/<file_name>.txt and print its content
     file_name = open("file_name.txt", "w")
     file_name.write(file_name + "\n")
     nums =  []
     for number in file_name:
       nums.append(int(number))
     return nums
nums = file_process()
print(nums)
     


if __name__ == '__main__':
    file_name = int(input("Enter a number between 1 and 10: "))
    file_process(file_name)