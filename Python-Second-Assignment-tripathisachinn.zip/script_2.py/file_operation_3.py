def write_to_file(file_name, file_contents):
     print("")
     # Add code to save data in variable file_contents to file named file_name
     outfile = open("file_name.txt", "w")
     
     outfile.write(file_name + "\n")
     
     outfile.write(file_contents + "\n")
     
     outfile.close()

if __name__ == '__main__':
    file_name = input("Enter the name of file: ")
    file_contents = input("Enter the contents to be stored in a file: ")
    write_to_file(file_name, file_contents)

# error PermissionError: [Errno 13] Permission denied: 'file_name.txt'