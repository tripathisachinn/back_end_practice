def orderdict(elements):
     print(elements)


if __name__ == '__main__':
    count_of_elements = int(input("Enter no of Elements:"))
    elements = []
    for i in range(1,count_of_elements+1):
        temp_variable = int(input("Input "+str(i)+":"))
        elements.append(i)
    orderdict(elements)

#working on it