def json_parse(json_string):
      # print the keys and values
    value=0
    # parse json and calculate 
    print("Total Marks:", value )


if __name__ == '__main__':
    # code for reading json file
    with open('subjects.json') as f:
      data = json.load(f)
      print (data)
    # Assign json data  to variable json_string
    json_parse(json_string)

