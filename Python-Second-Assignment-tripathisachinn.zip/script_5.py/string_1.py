def process_string(sentence):
     print("")


if __name__ == '__main__':
    sentence = input("Enter a long sentence:")
    process_string(sentence)