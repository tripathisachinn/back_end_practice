def append_ing(sentence):
     print("")


if __name__ == '__main__':
    sentence = input("Enter a string:")
    append_ing(sentence)