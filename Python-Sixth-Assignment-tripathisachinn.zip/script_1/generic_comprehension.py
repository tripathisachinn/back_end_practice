def generic_comprehension(input_object):
    
    generic_using_comp = # add comprehension logic here
    
    return generic_using_comp

if __name__ == '__main__':
    a=input("Add generic elements seperated by space: ").split(' ')
    output = generic_comprehension(a)
    print("Output generic list using generic comprehensions:", 
                                list(output))