def even_odd_lambda(list_object):
    odd_ctr = # Add lambda code here 
    even_ctr =  # Add lambda code here 
    return [odd_ctr, even_ctr] 


if __name__ == '__main__':
    a=input("Add list elements seperated by space ").split(' ')
    output = even_odd_lambda(a)
    print("\nNumber of even numbers in the above array: ", output[1])
    print("\nNumber of odd numbers in the above array: ", output[0])  