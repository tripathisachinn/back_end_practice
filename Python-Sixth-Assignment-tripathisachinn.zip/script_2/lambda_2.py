nums1 = [1, 4, 5, 6, 5] 
nums2 = [3, 5, 7, 2, 5] 


result = # Add lambda code here 
print("\nResult: after adding two list")
print(list(result))