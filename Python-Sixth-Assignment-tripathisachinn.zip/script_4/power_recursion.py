def power(N, P): 
  
    # Add recursion logic here and return value
  
# Driver program 
if __name__ == '__main__':
    a=int(input("Enter the number "))
    b=int(input("Enter Power "))
    
    print(power(a, b))