def recursive_list_sum(data_list):
	total = 0
	# Add recursion logic here

	return total

if __name__ == '__main__':
    a=input("Add list elements seperated by space ").split(' ')
    a = [ int(x) for x in a ]

    print(recursive_list_sum(a))