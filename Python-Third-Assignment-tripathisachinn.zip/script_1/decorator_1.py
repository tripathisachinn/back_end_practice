def text_statement(text):
    print(text)

def multiple_print(func):
    if count >= 0 :
      for x in range (count):
        print(text)
    else :
      print("Please provide a positive number")
    
if __name__ == '__main__':
    text = input("What do you want to print?\n")
    count = int(input("How many times do you want to print the statement?\n"))

    text_statement_decorator = multiple_print(text_statement)
    text_statement_decorator(text, count)