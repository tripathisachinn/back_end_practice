class Circle():
    def __init__(self, r):

    def area(self):
        return ""
    
    def circumference(self):
        return ""
    
    def __eq__(self, other):
        return ""
    
    def __add__(self, other):
        return ""
    
    def __gt__(self, other):
        return ""
    

if __name__ == '__main__':
    a=int(input("Enter Radius of circle 1:"))
    b=int(input("Enter Radius of circle 2:"))
    obj1=Circle(a)
    obj2=Circle(b)
    if obj1==obj2:
        print("Both Circles are Equal")
    elif obj1 > obj2:
        print("Circle 1 is bigger than Circle 2")
    else:
        print("Circle 2 is bigger than Circle 1")

