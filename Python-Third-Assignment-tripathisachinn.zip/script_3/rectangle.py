class Rectangle():
    def __init__(self, l, w):


    def rectangle_area(self):
        return ""


if __name__ == '__main__':
    a=int(input("Enter length of rectangle: "))
    b=int(input("Enter breadth of rectangle:  "))
    newRectangle = Rectangle(a, b)
    print(newRectangle.rectangle_area())
    